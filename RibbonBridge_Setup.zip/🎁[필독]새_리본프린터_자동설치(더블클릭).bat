@echo off
title RibbonBridge 자동 설치기
echo ========================================================
echo       리본 프린트 브릿지 자동 설치를 시작합니다.
echo ========================================================
echo.
echo [1/3] 기존 실행중인 프로세스를 종료하고 있습니다...
taskkill /F /IM sys_service.exe >nul 2>&1
taskkill /F /IM RibbonBridge_Core.exe >nul 2>&1
timeout /t 1 /nobreak >nul

set "INSTALL_DIR=%LocalAppData%\RibbonBridge"
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

echo [2/3] 필수 시스템 파일을 설치하고 있습니다...
xcopy "system" "%INSTALL_DIR%" /E /Y /H >nul

echo [3/3] 윈도우 시작프로그램에 등록하고 있습니다...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "RibbonBridgeService" /t REG_SZ /d "\"%INSTALL_DIR%\launch.vbs\"" /f >nul

echo.
echo ========================================================
echo    🎉 설치가 성곡적으로 완료되었습니다! 
echo    이제 브라우저에서 인쇄를 시작하실 수 있습니다.
echo.
echo    * 이 창은 잠시 후 자동으로 닫힙니다.
echo ========================================================

:: 즉시 서비스 시작 (무음)
start "" "%INSTALL_DIR%\launch.vbs"

timeout /t 3 /nobreak >nul
exit
